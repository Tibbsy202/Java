package QcoeMicrosite;

import static spark.Spark.*;

public class Main {

    public static void main(String[] args) {

        port(80);
        port(4567);

        staticFiles.location("/web");

        get("/index", (request, response) -> {
            response.status(200);
            response.redirect("index.html");
            return "ok";
        });

/*
        get("/index", (request, response) -> {
            response.status(200);
            response.redirect("index2.html");
            return "ok";
        });
        */
    }

}


